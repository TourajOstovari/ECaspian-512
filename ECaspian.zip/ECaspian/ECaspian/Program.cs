﻿using Microsoft.VisualBasic.CompilerServices;
using PGA;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace ConsoleApp1
{
    internal class Program
    {

        private static Int64 Sums = 1;
        private static byte[] v1;
        private static void Main(string[] args)
        {
            try
            {
                System.Threading.Tasks.Task task_hash = new System.Threading.Tasks.Task(Calc_Hash, args[0].ToString());
                task_hash.Start();
                task_hash.Wait();
            }
            catch
            {
                System.Threading.Tasks.Task task_hash = new System.Threading.Tasks.Task(Calc_Hash, null);
                task_hash.Start();
                task_hash.Wait();
            }
        }
        public static void Calc_Hash(object file)
        {
            Stopwatch st = new Stopwatch();

        Console:
            byte shift = 1;

            Console.Clear();
            Console.Title = "ECaspian-512 HASH FUNCTION DEVELOPED BY MR. TOURAJ OSTOVARI";
            Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("Write your string:\r\n");
            //
            try
            {

                System.IO.StreamReader streamReader = new System.IO.StreamReader(file.ToString(), Encoding.UTF8);
                //System.IO.StreamReader streamReader = new System.IO.StreamReader(@"C:\Users\Toraj\Downloads\Compressed\Udemy.Deep.dive.into.Windows.Presentation.Foundation.WPF_p30download.com.part5.rar", Encoding.UTF8);

                v1 = Encoding.UTF8.GetBytes(streamReader.ReadToEnd());
                //v1 = Encoding.Unicode.GetChars(System.IO.File.ReadAllBytes(file.ToString()));
            }
            catch
            {
                v1 = Encoding.UTF8.GetBytes(Console.ReadLine());

            }

            //Console.WriteLine("Going to beging");
            //Console.ReadLine();
            st.Start();
            BitArray A = new BitArray(4096, true);
            BitArray B = new BitArray(4096, true);
            BitArray C = new BitArray(4096, true);
            BitArray D = new BitArray(4096, true);

            BitArray A_ = new BitArray(4096, false);
            BitArray B_ = new BitArray(4096, false);
            BitArray C_ = new BitArray(4096, false);
            BitArray D_ = new BitArray(4096, false);

            int Index = 0;
            bool A_Time = true;
            bool B_Time = false;
            bool C_Time = false;
            bool D_Time = false;
            bool Jump_ = false;
            int Final_Counter = 0;
            string Temp_Append = "";
            long Counter_Index = 0;
            for (; Counter_Index < v1.Length;)
            {
                byte item = v1[Counter_Index++];
                bool IsAppened_ = false;
                if (++shift == 20) shift = 1;
                Sums += (item * 100);
                Sums += (Linear_congruential_generator.LCG_(shift, Sums, shift) * 20);
                Sums += Sums + Linear_congruential_generator.BEL_(shift, (Sums + shift + item) * 10, 31);
                string Binary = Convert.ToString(item, 2);

                int Index_ = (Binary.Length - 1);
                // Reverse ham dare rokh mide
                if (A_Time)
                {
                    if (Jump_ == true) { Jump_ = false; Index = 0; }
                    while (Index_ >= 0)
                    {
                        if (IsAppened_ == false)
                        {
                            if (Temp_Append.Length == 0)
                            {
                                if (Binary[Index_] == '1')
                                    A.Set(Index, true);
                                else if (Binary[Index_] == '0')
                                    A.Set(Index, false);
                                Index++; Index_--;
                            }
                            else
                            {
                                for (int i = Temp_Append.Length - 1; i >= 0; i--)
                                {
                                    if (Temp_Append[i] == '1') A.Set(Index++, true); else A.Set(Index++, false);
                                }
                                Temp_Append = "";
                            }
                        }
                        else if (IsAppened_ == true)
                        {
                            if (Binary[Index_] == '1')
                                Temp_Append += "1";
                            else if (Binary[Index_] == '0')
                                Temp_Append += "0";
                            Index_--;

                        }
                        if (Index == 4095)
                        {
                            A_Time = false;
                            B_Time = true;
                            Index = 0;
                            Jump_ = true;
                            if (Index_ >= 0)
                            {
                                IsAppened_ = true;
                            }
                        }
                    }
                }
                else if (B_Time)
                {
                    if (Jump_ == true) { Jump_ = false; Index = 0; }
                    while (Index_ >= 0)
                    {
                        if (IsAppened_ == false)
                        {
                            if (Temp_Append.Length == 0)
                            {
                                if (Binary[Index_] == '1')
                                    B.Set(Index, true);
                                else if (Binary[Index_] == '0')
                                    B.Set(Index, false);
                                Index++; Index_--;
                            }
                            else
                            {
                                for (int i = Temp_Append.Length - 1; i >= 0; i--)
                                {
                                    if (Temp_Append[i] == '1') B.Set(Index++, true); else B.Set(Index++, false);
                                }
                                Temp_Append = "";
                            }
                        }
                        else if (IsAppened_ == true)
                        {
                            if (Binary[Index_] == '1')
                                Temp_Append += "1";
                            else if (Binary[Index_] == '0')
                                Temp_Append += "0";
                            Index_--;

                        }
                        if (Index == 4095)
                        {
                            B_Time = false;
                            C_Time = true;
                            Index = 0;
                            Jump_ = true;
                            if (Index_ >= 0)
                            {
                                IsAppened_ = true;
                            }
                        }
                    }
                }
                else if (C_Time)
                {
                    if (Jump_ == true) { Jump_ = false; Index = 0; }
                    while (Index_ >= 0)
                    {
                        if (IsAppened_ == false)
                        {
                            if (Temp_Append.Length == 0)
                            {
                                if (Binary[Index_] == '1')
                                    C.Set(Index, true);
                                else if (Binary[Index_] == '0')
                                    C.Set(Index, false);
                                Index++; Index_--;
                            }
                            else
                            {
                                for (int i = Temp_Append.Length - 1; i >= 0; i--)
                                {
                                    if (Temp_Append[i] == '1') C.Set(Index++, true); else C.Set(Index++, false);
                                }
                                Temp_Append = "";
                            }
                        }
                        else if (IsAppened_ == true)
                        {
                            if (Binary[Index_] == '1')
                                Temp_Append += "1";
                            else if (Binary[Index_] == '0')
                                Temp_Append += "0";
                            Index_--;

                        }
                        if (Index == 4095)
                        {
                            C_Time = false;
                            D_Time = true;
                            Index = 0;
                            Jump_ = true;
                            if (Index_ >= 0)
                            {
                                IsAppened_ = true;
                            }
                        }
                    }
                }
                else if (D_Time)
                {
                    if (Jump_ == true) { Jump_ = false; Index = 0; }

                    while (Index_ >= 0)
                    {
                        if (IsAppened_ == false)
                        {
                            if (Temp_Append.Length == 0)
                            {
                                if (Binary[Index_] == '1')
                                    D.Set(Index, true);
                                else if (Binary[Index_] == '0')
                                    D.Set(Index, false);
                                Index++; Index_--;
                            }
                            else
                            {
                                for (int i = Temp_Append.Length - 1; i >= 0; i--)
                                {
                                    if (Temp_Append[i] == '1') D.Set(Index++, true); else D.Set(Index++, false);
                                }
                                Temp_Append = "";
                            }
                        }
                        else if (IsAppened_ == true)
                        {
                            if (Binary[Index_] == '1')
                                Temp_Append += "1";
                            else if (Binary[Index_] == '0')
                                Temp_Append += "0";
                            Index_--;

                        }
                        if (Index == 4095)
                        {
                            A_Time = true;
                            D_Time = false;
                            Index = 0;
                            Jump_ = true;
                            if (Index_ >= 0)
                            {
                                IsAppened_ = true;
                            }
                            Final_Counter++;
                        }
                    }
                }
                B = B.Xor(A);
                C = B.Xor(C);
                D = C.Xor(D);
                A = D.Xor(A);
                A_ = A_.Xor(A);
                B_ = B_.Xor(B);
                C_ = C_.Xor(C);
                D_ = D_.Xor(D);


                if (Final_Counter == 2500) break;

            }

            C_ = C_.Not();
            {
                bool first_time = true;
                for (int i = 0; i < (B_.Count - 1); i++)
                {
                    if (B_.Get(i) == true)
                        if (first_time == false) B_.Set(i, false);
                    if (first_time) first_time = false; else first_time = true;

                }
            }
            {
                bool first_time = true;
                for (int i = 0; i < (D_.Count - 1); i++)
                {
                    if (D_.Get(i) == true)
                        if (first_time == false) D_.Set(i, false);
                    if (first_time) first_time = false; else first_time = true;

                }
            }
            A_ = A_.Xor(B_);
            B_ = C_.Xor(D_);
            A_ = A_.And(B_).Not();

            {

                PGA.Linear_congruential_generator.BEL(Sums, shift, 4095);

            }
            A_ = A_.Xor(Linear_congruential_generator.lst);

            {
                int i_ = 2048;
                for (int i = 0; i < 2048; i++)
                {
                    B_.Set(i, A_.Get(i_++));
                }
                A_.Length = 2048;
                B_.Length = 2048;
                A_ = A_.And(B_).Not();

            }
            {
                Linear_congruential_generator.lst.SetAll(false);
                Linear_congruential_generator.lst.Length = 2048;
                PGA.Linear_congruential_generator.BEL((Sums * 2), (shift * 2), 2047);

            }
            A_ = A_.And(Linear_congruential_generator.lst).Not();

            {
                int i_ = 1024;
                for (int i = 0; i < 1024; i++)
                {
                    B_.Set(i, A_.Get(i_++));
                }
                A_.Length = 1024;
                B_.Length = 1024;
                A_ = A_.Xor(B_);

            }
            {
                Linear_congruential_generator.lst.SetAll(false);
                Linear_congruential_generator.lst.Length = 1024;
                PGA.Linear_congruential_generator.BEL((Sums * 3), (shift * 3), 1023);

            }
            A_ = A_.Xor(Linear_congruential_generator.lst);

            {
                int i_ = 512;
                for (int i = 0; i < 512; i++)
                {
                    B.Set(i, A_.Get(i_++));
                }
                A_.Length = 512;
                B_.Length = 512;
                A_ = A_.And(B_).Not();

            }
            {
                Linear_congruential_generator.lst.SetAll(false);
                Linear_congruential_generator.lst.Length = 512;
                PGA.Linear_congruential_generator.BEL((Sums * 4), (shift * 4), 511);

            }
            A_ = A_.And(Linear_congruential_generator.lst).Not().LeftShift(shift);
            string result = "";
            Console.WriteLine($"Hash:");
            for (int i = 0; i < A_.Count; i++)
            {
                if (A_.Get(i))
                {
                    result += "1";
                }
                else
                {
                    result += "0";
                }
                if (result.Length == 4)
                {
                    Console.Write(Convert.ToInt32(result, 2).ToString("X"));
                    result = "";
                }
            }





            st.Stop();
            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("\nStopwatch:" + st.Elapsed);
            Console.ReadLine();
            Sums = 1;
            file = null;
            Linear_congruential_generator.lst.Length = 4096;
            Linear_congruential_generator.lst.SetAll(false);
            goto Console;
        }
    }

}